const express = require('express');
const crypto = require('crypto');
const router = express.Router();
const { pool } = require('../db');
const cache = require('../lib/memoryCache');
const pageViewQueue = require('../lib/pageViewQueue');

const ACCESS_TOKEN_CACHE_TTL_MS = 5000;

function getClientIp(req) {
  const forwarded = String(req.headers['x-forwarded-for'] || '').split(',')[0].trim();
  if (forwarded) return forwarded.slice(0, 64);

  const remote = req.socket && req.socket.remoteAddress ? String(req.socket.remoteAddress) : '';
  return remote.slice(0, 64) || 'unknown';
}

function getSessionId(req) {
  const value = String(req.headers.cookie || '')
    .split(';')
    .map(part => part.trim())
    .find(part => part.startsWith('visitor_session='));

  if (value) return value.slice('visitor_session='.length).slice(0, 64);

  return crypto.randomBytes(12).toString('hex');
}

function getVisitorUid(req) {
  const value = String(req.headers.cookie || '')
    .split(';')
    .map(part => part.trim())
    .find(part => part.startsWith('visitor_uid='));

  if (value) return value.slice('visitor_uid='.length).slice(0, 64);

  return crypto.randomBytes(12).toString('hex');
}

function getAccessTokenValue(req) {
  const queryToken = String(req.query.token || '').trim();
  if (queryToken) return queryToken.slice(0, 128);

  const cookieToken = String(req.headers.cookie || '')
    .split(';')
    .map(part => part.trim())
    .find(part => part.startsWith('access_token='));

  if (cookieToken) return decodeURIComponent(cookieToken.slice('access_token='.length)).slice(0, 128);
  return '';
}

async function getActiveAccessTokenId(req, res) {
  const token = getAccessTokenValue(req);
  if (!token) return null;

  const cacheKey = `access-token:${token}`;
  const cachedAccessTokenId = cache.get(cacheKey);
  if (cachedAccessTokenId) {
    res.cookie('access_token', token, {
      httpOnly: true,
      sameSite: 'lax',
      maxAge: 365 * 24 * 60 * 60 * 1000,
      path: '/'
    });
    return cachedAccessTokenId;
  }

  const [[row]] = await pool.execute(
    'SELECT id FROM access_tokens WHERE token = ? AND is_active = 1 LIMIT 1',
    [token]
  );
  if (!row) return null;

  cache.set(cacheKey, row.id, ACCESS_TOKEN_CACHE_TTL_MS);
  res.cookie('access_token', token, {
    httpOnly: true,
    sameSite: 'lax',
    maxAge: 365 * 24 * 60 * 60 * 1000,
    path: '/'
  });
  return row.id;
}

async function requireAccessToken(req, res) {
  const accessTokenId = await getActiveAccessTokenId(req, res);
  if (accessTokenId) return accessTokenId;

  res.status(403).send('需要有效访问 Token');
  return null;
}

function parseNovelAndChapter(pathname) {
  const novelMatch = pathname.match(/^\/novel\/(\d+)(?:\/(\d+))?$/);
  if (!novelMatch) return { novelId: null, chapterId: null };
  return {
    novelId: Number(novelMatch[1]),
    chapterId: novelMatch[2] ? Number(novelMatch[2]) : null
  };
}

async function recordPageView(req, res, next) {
  try {
    if (req.method !== 'GET') {
      return next();
    }

    const pathname = req.path || req.originalUrl || '/';
    if (pathname.startsWith('/admin') || pathname.startsWith('/css') || pathname.startsWith('/js') || pathname.startsWith('/favicon') || pathname === '/healthz') {
      return next();
    }

    const accessTokenId = await requireAccessToken(req, res);
    if (!accessTokenId) return;

    const visitorUid = getVisitorUid(req);
    const sessionId = getSessionId(req);
    const visitorIp = getClientIp(req);
    const userAgent = String(req.headers['user-agent'] || 'unknown').slice(0, 255);
    const referrer = String(req.headers.referer || req.headers.referrer || '').slice(0, 255) || null;
    const { novelId, chapterId } = parseNovelAndChapter(pathname);
    res.cookie('visitor_uid', visitorUid, {
      httpOnly: true,
      sameSite: 'lax',
      maxAge: 365 * 24 * 60 * 60 * 1000,
      path: '/'
    });
    res.cookie('visitor_session', sessionId, {
      httpOnly: true,
      sameSite: 'lax',
      maxAge: 60 * 60 * 24 * 365 * 1000,
      path: '/'
    });

    pageViewQueue.enqueue({
      visitorUid,
      accessTokenId,
      sessionId,
      visitorIp,
      userAgent,
      path: pathname,
      referrer,
      novelId,
      chapterId
    });

    next();
  } catch (err) {
    next(err);
  }
}

router.use(recordPageView);

function sendCachedHtml(res, cacheKey) {
  const html = cache.get(cacheKey);
  if (!html) return false;

  res.set('X-Cache', 'HIT');
  res.send(html);
  return true;
}

function renderAndCache(req, res, next, cacheKey, view, data) {
  res.render(view, data, (err, html) => {
    if (err) return next(err);

    cache.set(cacheKey, html);
    res.set('X-Cache', 'MISS');
    res.send(html);
  });
}

function splitParagraphs(chapter) {
  const cacheKey = `paragraphs:${chapter.id}`;
  const cached = cache.get(cacheKey);
  if (cached) return cached;

  const paragraphs = chapter.content
    .split(/\n\n+/)
    .map(p => p.trim())
    .filter(p => p.length > 0);

  cache.set(cacheKey, paragraphs);
  return paragraphs;
}

// Homepage — directly shows TOC of the first novel
router.get('/', async (req, res, next) => {
  try {
    const cacheKey = 'html:home';
    if (sendCachedHtml(res, cacheKey)) return;

    const [[novel]] = await pool.execute(
      'SELECT id, title, description FROM novels ORDER BY id LIMIT 1'
    );
    if (!novel) return res.send('暂无小说');

    const [chapters] = await pool.execute(
      'SELECT id, chapter_number, title, created_at FROM chapters WHERE novel_id = ? ORDER BY chapter_number ASC',
      [novel.id]
    );

    renderAndCache(req, res, next, cacheKey, 'novel', { novel, chapters });
  } catch (err) {
    next(err);
  }
});

// Novel detail + table of contents
router.get('/novel/:id', async (req, res, next) => {
  try {
    const cacheKey = `html:novel:${req.params.id}`;
    if (sendCachedHtml(res, cacheKey)) return;

    const [[novel]] = await pool.execute(
      'SELECT id, title, description, created_at FROM novels WHERE id = ?',
      [req.params.id]
    );
    if (!novel) return res.status(404).render('404', { url: req.originalUrl });

    const [chapters] = await pool.execute(
      'SELECT id, chapter_number, title, created_at FROM chapters WHERE novel_id = ? ORDER BY chapter_number ASC',
      [req.params.id]
    );

    renderAndCache(req, res, next, cacheKey, 'novel', { novel, chapters });
  } catch (err) {
    next(err);
  }
});

// Chapter reading page
router.get('/novel/:id/:chapterNum', async (req, res, next) => {
  try {
    const { id, chapterNum } = req.params;
    const cacheKey = `html:chapter:${id}:${chapterNum}`;
    if (sendCachedHtml(res, cacheKey)) return;

    const [[novel]] = await pool.execute(
      'SELECT id, title FROM novels WHERE id = ?',
      [id]
    );
    if (!novel) return res.status(404).render('404', { url: req.originalUrl });

    const [[chapter]] = await pool.execute(
      'SELECT id, chapter_number, title, content FROM chapters WHERE novel_id = ? AND chapter_number = ?',
      [id, chapterNum]
    );
    if (!chapter) return res.status(404).render('404', { url: req.originalUrl });

    chapter.paragraphs = splitParagraphs(chapter);

    // Previous chapter
    const [[prevChapter]] = await pool.execute(
      'SELECT chapter_number, title FROM chapters WHERE novel_id = ? AND chapter_number < ? ORDER BY chapter_number DESC LIMIT 1',
      [id, chapterNum]
    );

    // Next chapter
    const [[nextChapter]] = await pool.execute(
      'SELECT chapter_number, title FROM chapters WHERE novel_id = ? AND chapter_number > ? ORDER BY chapter_number ASC LIMIT 1',
      [id, chapterNum]
    );

    renderAndCache(req, res, next, cacheKey, 'chapter', { novel, chapter, prevChapter, nextChapter });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
